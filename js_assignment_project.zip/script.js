// ============================
// PART 1: Variables & Conditionals
// ============================
let name = "Julie";
let hour = new Date().getHours();

// Conditional greeting
let greetingMessage;
if (hour < 12) {
  greetingMessage = "Good morning, " + name + "!";
} else if (hour < 18) {
  greetingMessage = "Good afternoon, " + name + "!";
} else {
  greetingMessage = "Good evening, " + name + "!";
}

// DOM Interaction #1: Show greeting on the page
document.getElementById("greeting").textContent = greetingMessage;


// ============================
// PART 2: Custom Functions
// ============================

// Function 1: Generate a random color
function getRandomColor() {
  let letters = "0123456789ABCDEF";
  let color = "#";
  for (let i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
}

// Function 2: Change background color using the random color
function changeBackgroundColor() {
  document.body.style.backgroundColor = getRandomColor();
}

// DOM Interaction #2: Add event listener to button
document.getElementById("colorBtn").addEventListener("click", changeBackgroundColor);


// ============================
// PART 3: Loops
// ============================

// Loop 1: For loop - create a list of numbers
let numberList = document.getElementById("numberList");
for (let i = 1; i <= 5; i++) {
  let li = document.createElement("li");
  li.textContent = "Number " + i;
  numberList.appendChild(li);
}

// Loop 2: While loop - countdown in console
let count = 5;
while (count > 0) {
  console.log("Countdown: " + count);
  count--;
}


// ============================
// PART 4: More DOM Interactions
// ============================

// DOM Interaction #3: Change text color of greeting after 3 seconds
setTimeout(() => {
  document.getElementById("greeting").style.color = "blue";
}, 3000);